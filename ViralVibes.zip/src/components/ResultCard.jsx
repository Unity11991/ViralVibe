import React, { useState } from 'react';
import { Copy, Check, Clock, Hash, MessageSquare } from 'lucide-react';

const ResultCard = ({ title, content, icon: Icon, delay = 0 }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(content);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div
            className="glass-panel p-6 text-left animate-fade-in hover:bg-slate-800/40 transition-colors"
            style={{ animationDelay: `${delay}ms` }}
        >
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-purple-400">
                    <Icon size={20} />
                    <h3 className="font-semibold text-lg">{title}</h3>
                </div>
                <button
                    onClick={handleCopy}
                    className="p-2 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-white"
                    title="Copy to clipboard"
                >
                    {copied ? <Check size={18} className="text-green-400" /> : <Copy size={18} />}
                </button>
            </div>

            <div className="text-slate-200 leading-relaxed whitespace-pre-wrap font-medium">
                {content}
            </div>
        </div>
    );
};

export const ResultsSection = ({ results }) => {
    if (!results) return null;

    return (
        <div className="grid gap-6 mt-8 w-full max-w-2xl mx-auto">
            <ResultCard
                title="Best Caption"
                content={results.captions[0]}
                icon={MessageSquare}
                delay={100}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <ResultCard
                    title="Viral Hashtags"
                    content={results.hashtags.join(' ')}
                    icon={Hash}
                    delay={200}
                />
                <ResultCard
                    title="Best Time to Post"
                    content={results.bestTime}
                    icon={Clock}
                    delay={300}
                />
            </div>

            {results.captions.length > 1 && (
                <div className="glass-panel p-6 text-left animate-fade-in" style={{ animationDelay: '400ms' }}>
                    <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4">Alternative Captions</h3>
                    <ul className="space-y-3">
                        {results.captions.slice(1).map((caption, idx) => (
                            <li key={idx} className="flex items-start gap-3 text-slate-300 pb-3 border-b border-slate-700/50 last:border-0 last:pb-0">
                                <span className="text-purple-500 mt-1">•</span>
                                {caption}
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default ResultCard;
