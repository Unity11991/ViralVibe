import React from 'react';
import { Settings, Key, Hash, MessageCircle, CheckCircle } from 'lucide-react';

const TONES = [
    { id: 'witty', label: 'Witty & Fun', emoji: '😜' },
    { id: 'professional', label: 'Professional', emoji: '💼' },
    { id: 'aesthetic', label: 'Aesthetic', emoji: '✨' },
    { id: 'inspirational', label: 'Inspirational', emoji: '🌟' },
    { id: 'sarcastic', label: 'Sarcastic', emoji: '😏' },
];

const PLATFORMS = [
    { id: 'instagram', label: 'Instagram', icon: '📸' },
    { id: 'linkedin', label: 'LinkedIn', icon: '👔' },
    { id: 'twitter', label: 'Twitter / X', icon: '🐦' },
    { id: 'tiktok', label: 'TikTok', icon: '🎵' },
];

const OptionsPanel = ({ settings, onSettingsChange }) => {
    const isEnvKey = !!import.meta.env.VITE_GROQ_API_KEY;
    const isEnvModel = !!import.meta.env.VITE_AI_MODEL;

    const handleChange = (key, value) => {
        onSettingsChange({ ...settings, [key]: value });
    };

    return (
        <div className="glass-panel p-8 w-full max-w-2xl mx-auto mb-10 animate-fade-in">
            {(!isEnvKey || !isEnvModel) && (
                <div className="flex items-center gap-3 mb-8 text-purple-300 border-b border-white/5 pb-4">
                    <Settings size={22} />
                    <h3 className="font-bold text-xl tracking-wide">Customize Your Vibe</h3>
                </div>
            )}

            <div className="space-y-8">
                {/* API Key Section */}
                {!isEnvKey && (
                    <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-300 flex items-center gap-2 uppercase tracking-wider">
                            <Key size={14} /> Groq API Key
                        </label>
                        <input
                            type="password"
                            value={settings.apiKey}
                            onChange={(e) => handleChange('apiKey', e.target.value)}
                            placeholder="Enter your Groq API Key"
                            className="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3.5 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
                        />
                        <p className="text-xs text-slate-500 ml-1">
                            Your key is stored locally in your browser for this session only.
                        </p>
                    </div>
                )}

                {/* Model Selector */}
                {!isEnvModel && (
                    <div className="space-y-3">
                        <label className="text-sm font-semibold text-slate-300 flex items-center gap-2 uppercase tracking-wider">
                            <Settings size={14} /> AI Model
                        </label>
                        <input
                            type="text"
                            value={settings.model}
                            onChange={(e) => handleChange('model', e.target.value)}
                            placeholder="e.g., llama-3.2-11b-vision-preview"
                            className="w-full bg-slate-900/50 border border-slate-700 rounded-xl px-4 py-3.5 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-all"
                        />
                    </div>
                )}

                {/* Platform Selector */}
                <div className="space-y-3">
                    <label className="text-sm font-semibold text-slate-300 flex items-center gap-2 uppercase tracking-wider">
                        <Hash size={14} /> Platform
                    </label>
                    <div className="flex flex-wrap gap-3">
                        {PLATFORMS.map((platform) => (
                            <button
                                key={platform.id}
                                onClick={() => handleChange('platform', platform.id)}
                                className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-300
                  ${settings.platform === platform.id
                                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/30 scale-105'
                                        : 'bg-slate-800/40 text-slate-400 hover:bg-slate-700/60 hover:text-white border border-transparent hover:border-white/10'
                                    }`}
                            >
                                <span>{platform.icon}</span>
                                {platform.label}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Tone Selector */}
                <div className="space-y-3">
                    <label className="text-sm font-semibold text-slate-300 flex items-center gap-2 uppercase tracking-wider">
                        <MessageCircle size={14} /> Tone of Voice
                    </label>
                    <div className="flex flex-wrap gap-3">
                        {TONES.map((tone) => (
                            <button
                                key={tone.id}
                                onClick={() => handleChange('tone', tone.id)}
                                className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-300
                  ${settings.tone === tone.id
                                        ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-lg shadow-pink-500/30 scale-105'
                                        : 'bg-slate-800/40 text-slate-400 hover:bg-slate-700/60 hover:text-white border border-transparent hover:border-white/10'
                                    }`}
                            >
                                <span>{tone.emoji}</span>
                                {tone.label}
                            </button>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OptionsPanel;
