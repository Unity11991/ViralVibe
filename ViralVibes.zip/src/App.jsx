import React, { useState, useEffect } from 'react';
import { Sparkles, AlertCircle, History } from 'lucide-react';
import ImageUploader from './components/ImageUploader';
import { ResultsSection } from './components/ResultCard';
import OptionsPanel from './components/OptionsPanel';
import SeoWrapper from './components/SeoWrapper';
import HistoryPanel from './components/HistoryPanel';
import ProModal from './components/ProModal';
import Navbar from './components/Navbar';
import { analyzeImage } from './utils/aiService';

function App() {
  const [image, setImage] = useState(null);
  const [results, setResults] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState(null);

  // Theme State
  const [theme, setTheme] = useState(() => localStorage.getItem('viralvibe-theme') || 'midnight');

  // History State
  const [history, setHistory] = useState(() => {
    const saved = localStorage.getItem('viralvibe-history');
    return saved ? JSON.parse(saved) : [];
  });
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // Monetization State
  const [showProModal, setShowProModal] = useState(false);
  const [dailyUsage, setDailyUsage] = useState(() => {
    const saved = localStorage.getItem('viralvibe-usage');
    if (saved) {
      const { count, date } = JSON.parse(saved);
      if (date === new Date().toDateString()) {
        return count;
      }
    }
    return 0;
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('viralvibe-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('viralvibe-history', JSON.stringify(history));
  }, [history]);

  useEffect(() => {
    localStorage.setItem('viralvibe-usage', JSON.stringify({
      count: dailyUsage,
      date: new Date().toDateString()
    }));
  }, [dailyUsage]);

  const [settings, setSettings] = useState({
    apiKey: import.meta.env.VITE_GROQ_API_KEY || '',
    platform: 'instagram',
    tone: 'witty',
    model: import.meta.env.VITE_AI_MODEL || 'llama-3.2-11b-vision-preview'
  });

  const handleImageSelect = (file, previewUrl) => {
    setImage(file);
    setResults(null);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!image) return;

    // Check Daily Limit (e.g., 5 free generations)
    // Limit disabled for now as per user request (Unlimited Access)
    /* if (dailyUsage >= 5) {
      setShowProModal(true);
      return;
    } */

    if (!settings.apiKey) {
      setError("Please enter your Groq API Key to proceed.");
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const data = await analyzeImage(image, settings);
      setResults(data);
      setDailyUsage(prev => prev + 1);

      // Add to history
      const newHistoryItem = {
        id: Date.now(),
        timestamp: Date.now(),
        captions: data.captions,
        hashtags: data.hashtags,
        bestTime: data.bestTime,
        platform: settings.platform,
        tone: settings.tone
      };
      setHistory(prev => [newHistoryItem, ...prev]);
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const restoreHistoryItem = (item) => {
    setResults({
      captions: item.captions,
      hashtags: item.hashtags,
      bestTime: item.bestTime
    });
    setSettings(prev => ({
      ...prev,
      platform: item.platform,
      tone: item.tone
    }));
    setIsHistoryOpen(false);
    // Note: We can't restore the image file object easily, so we just show results
    // Ideally we'd store the image as base64 but that might exceed localStorage limits
  };

  const deleteHistoryItem = (id) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  return (
    <div className="min-h-screen flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8 pt-32">
      <SeoWrapper />
      <ProModal isOpen={showProModal} onClose={() => setShowProModal(false)} />

      <Navbar
        currentTheme={theme}
        onThemeChange={setTheme}
        onHistoryClick={() => setIsHistoryOpen(true)}
      />

      <HistoryPanel
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelect={restoreHistoryItem}
        onDelete={deleteHistoryItem}
      />

      <header className="mb-12 text-center space-y-4 animate-fade-in">
        <h1 className="text-5xl font-bold tracking-tight text-white mb-2">
          Viral<span className="text-gradient">Vibe</span>
        </h1>
        <p className="text-lg text-slate-400 max-w-lg mx-auto">
          Upload your photo and let AI generate the perfect caption, viral hashtags, and posting schedule.
        </p>
      </header>

      <main className="w-full max-w-2xl mx-auto space-y-8">
        <OptionsPanel settings={settings} onSettingsChange={setSettings} />

        <ImageUploader
          onImageSelect={handleImageSelect}
          isAnalyzing={isAnalyzing}
        />

        {error && (
          <div className="glass-panel p-4 border-red-500/50 bg-red-500/10 flex items-center gap-3 text-red-200 animate-fade-in">
            <AlertCircle className="text-red-500" />
            {error}
          </div>
        )}

        {image && !results && !isAnalyzing && (
          <div className="flex justify-center animate-fade-in">
            <button
              onClick={handleAnalyze}
              className="btn-primary flex items-center gap-2 text-lg px-8 py-4 shadow-lg shadow-purple-500/20"
            >
              <Sparkles size={20} />
              Generate Magic
            </button>
          </div>
        )}

        <ResultsSection results={results} />
      </main>

      <footer className="mt-20 text-slate-500 text-sm">
        <p>© 2025 ViralVibe AI. Crafted for creators.</p>
      </footer>
    </div>
  );
}

export default App;
